package com.org.sort;

import java.util.TreeSet;

public class SortDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//TreeSet<Employee> emp=new TreeSet<Employee>();
TreeSet sortByEmpId=new TreeSet(new CompareById());
Employee e1=new Employee(100, "Virat", "rane", 5000, new Address(200, "Vssnagar", "delhi"),new Department(300, "library", "delhi"));
Employee e2=new Employee(108, "Ajay", "solanki", 9000, new Address(208, "rvnagar", "chennai"),new Department(308, "math", "chennai"));
Employee e3=new Employee(104, "Bijay", "sindhe", 7000, new Address(204, "cssnagar", "hyd"),new Department(304, "chemist", "hyd"));
Employee e4=new Employee(106, "China", "singh", 6000, new Address(206, "itcnagar", "bangalore"),new Department(303, "eng", "bangalore"));

sortByEmpId.add(e1);
sortByEmpId.add(e2);
sortByEmpId.add(e3);
sortByEmpId.add(e4);
System.out.println(sortByEmpId);

TreeSet sortByEmpFirstName=new TreeSet(new CompareByFirstName());
sortByEmpFirstName.add(e1);
sortByEmpFirstName.add(e2);
sortByEmpFirstName.add(e3);
sortByEmpFirstName.add(e4);
System.out.println(sortByEmpFirstName);

TreeSet sortBySal=new TreeSet(new CompareBySalary());
sortBySal.add(e1);
sortBySal.add(e2);
sortBySal.add(e3);
sortBySal.add(e4);
System.out.println(sortBySal);

TreeSet sortByDeptLoc=new TreeSet(new CompareByDeptLoc());
sortByDeptLoc.add(e1);
sortByDeptLoc.add(e2);
sortByDeptLoc.add(e3);
sortByDeptLoc.add(e4);
System.out.println(sortByDeptLoc);

TreeSet sortByCity=new TreeSet(new CompareByCity());
sortByCity.add(e1);
sortByCity.add(e2);
sortByCity.add(e3);
sortByCity.add(e4);
System.out.println(sortByCity);


	}

}
