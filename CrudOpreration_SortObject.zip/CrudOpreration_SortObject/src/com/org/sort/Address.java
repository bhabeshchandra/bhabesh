package com.org.sort;

public class Address {
	
 int addressId;
 String streetName;
 String city;


@Override
public String toString() {
	return "Address [addressId=" + addressId + ", streetName=" + streetName + ", city=" + city + "]";
}

public Address(int addressId, String streetName, String city) {
	super();
	this.addressId = addressId;
	this.streetName = streetName;
	this.city = city;
}
}
