package com.org.sort;

public class Employee implements Comparable{

	 int employeeId;
	 String firstName;
	 String lastName;
	 int salary;
	 Address address;
	 Department department;
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", salary=" + salary + ", address=" + address + ", department=" + department + "]";
	}






	public Employee(int employeeId, String firstName, String lastName, int salary, Address address,
			Department department) {
		//super();
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.address = address;
		this.department = department;
	}



	
	@Override
	public int compareTo(Object obj) {
		// TODO Auto-generated method stub
		Employee e=(Employee) obj;
		if(this.employeeId<e.employeeId)
			return -1;
		else if(this.employeeId<e.employeeId)
			return 1;
		return 0;
	}
	
		
}
