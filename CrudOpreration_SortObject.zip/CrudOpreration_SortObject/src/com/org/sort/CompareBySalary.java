package com.org.sort;

import java.util.Comparator;

public class CompareBySalary implements Comparator {

	@Override
	public int compare(Object obj1, Object obj2) {
		// TODO Auto-generated method stub
		Employee e1=(Employee) obj1;
		Employee e2=(Employee) obj2;
		Integer s1=e1.salary;
		Integer s2=e2.salary;
		return s1.compareTo(s2);
	}

}
