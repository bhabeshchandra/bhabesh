package com.org.sort;

public class Department {
	
		 int departmentId;
		 String departmentName;
		 String location;
		
		public Department(int departmentId, String departmentName, String location) {
			super();
			this.departmentId = departmentId;
			this.departmentName = departmentName;
			this.location = location;
		}
		@Override
		public String toString() {
			return "Department [departmentId=" + departmentId + ", departmentName=" + departmentName + ", location="
					+ location + "]";
		}
		
		
		}
