package com.org.sort;

import java.util.Comparator;

public class CompareByFirstName implements Comparator {

	@Override
	public int compare(Object obj1, Object obj2) {
		// TODO Auto-generated method stub
		Employee e1=(Employee) obj1;
		Employee e2=(Employee) obj2;
		String s1=e1.firstName;
		String s2=e2.firstName;
		return s1.compareTo(s2);
	}

}
