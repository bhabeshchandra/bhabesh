package org.cap.criteria;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.cap.model.Customer;

public class RestrictionNot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("capg");
		EntityManager entityManager = entityManagerFactory.createEntityManager();

		Department dept1 = new Department(101, "Accounting", 1001);
		Department dept2 = new Department(102, "Sales", 1002);
		Department dept3 = new Department(103, "Operation", 1003);
		Department dept4 = new Department(104, "Research", 1004);

		entityManager.getTransaction().begin();
		entityManager.persist(dept1);
		entityManager.persist(dept2);
		entityManager.persist(dept3);
		entityManager.persist(dept4);
		
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Department> query = criteriaBuilder.createQuery(Department.class);
		  Root<Department> person = query.from(Department.class);
		  Predicate predicate = criteriaBuilder.equal(person.get("deptid"), 1001);
		  query.select(person)
		       .where(predicate.not());
		  TypedQuery<Department> typedQuery = entityManager.createQuery(query);
		  List<Department> lst = typedQuery.getResultList();

		for (Department dept : lst) {
			System.out.print(dept.getDeptid());
			System.out.print("\t" + dept.getDeptname());
			System.out.println("\t" + dept.getDeptloc());
		}

		entityManager.getTransaction().commit();
		entityManager.close();
		entityManagerFactory.close();

	}

}
