package com.org.cs;

import java.util.Scanner;

public class ConsecutiveSum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long number;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number ::");
		number = sc.nextInt();
		System.out.println(consecutive(number));
	}

	static long consecutive(long num) {
		int count = 0;
		for (int i = 1; i * (i + 1) < 2 * num; i++) {
			float check = (float) ((1.0 * num - (i * (i + 1)) / 2) / (i + 1));
			if (check - (int) check == 0.0)
				count++;
		}
		return count;
	}
}
