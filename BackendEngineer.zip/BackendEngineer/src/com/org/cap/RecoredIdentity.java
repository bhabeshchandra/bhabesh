package com.org.cap;

import java.time.LocalDate;

public class RecoredIdentity {

	private String transactionID;
	private String accountID;
	private LocalDate postingDate;
	private Double amount;

	public RecoredIdentity(String transactionID, String accountID, LocalDate dateTime, Double amount) {
	this.transactionID = transactionID;
	this.accountID = accountID;
	this.postingDate = dateTime;
	this.amount = amount;
	}

	public String getTransactionID() {
		return transactionID;
	}

	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}

	public String getAccountID() {
		return accountID;
	}

	public void setAccountID(String accountID) {
		this.accountID = accountID;
	}

	public LocalDate getPostingDate() {
		return postingDate;
	}

	public void setPostingDate(LocalDate postingDate) {
		this.postingDate = postingDate;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}
	
	
	
	@Override
	public String toString() {
	return "RecoredIdentity [transactionID=" + transactionID + ", accountID=" + accountID + ", postingDate=" + postingDate
	+ ", amount=" + amount + "]";
	}

	@Override
	public boolean equals(Object obj) {

		RecoredIdentity rcg = (RecoredIdentity) obj;
	if (this.getAccountID().equals(rcg.getAccountID()) && this.getAmount().equals(rcg.getAmount())
	&& this.getPostingDate().equals(rcg.getPostingDate())) {
	return true;
	}
	return false;
	}
	
	


}
