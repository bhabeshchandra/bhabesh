package com.org.cap;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

public class DataUtil {
	static DateTimeFormatter date = DateTimeFormatter.ofPattern("dd-MMM-yyyy", Locale.ENGLISH);
	public static List<RecoredIdentity> getFileData(String fileName) throws IOException {

		List<RecoredIdentity> list = new ArrayList<RecoredIdentity>();
		try (Stream<String> stream = Files.lines(Paths.get(fileName), StandardCharsets.UTF_8)) {
			stream.forEach(s -> {
				String[] ar = s.split(";");
				LocalDate dateTime = LocalDate.parse(ar[2].trim(), date);
				RecoredIdentity r = new RecoredIdentity(ar[0], ar[1], dateTime, Double.valueOf(ar[3]));
				list.add(r);
			});
		} catch (IOException e) {
			e.printStackTrace();
		}

		return list;
	}
	
	public static boolean dateCompByWeak(LocalDate day1, LocalDate day2) {

		if ((day1.getDayOfWeek().equals(DayOfWeek.FRIDAY)) && (day2.getDayOfWeek().equals(DayOfWeek.SATURDAY)
				|| day2.getDayOfWeek().equals(DayOfWeek.SUNDAY) || day2.getDayOfWeek().equals(DayOfWeek.MONDAY)
		)) {
			return true;
		}
		if (day1.equals(day2.plusDays(-1))) {
			return true;
		}
		return false;
	}

}
