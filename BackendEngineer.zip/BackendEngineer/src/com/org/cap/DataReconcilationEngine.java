package com.org.cap;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DataReconcilationEngine {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String exact = "";
		String week = "";
		String breakX = "";
		String breakY = "";
		Map<String, String> map = new HashMap<>();

		List<RecoredIdentity> xData = DataUtil.getFileData("X.txt");
		List<RecoredIdentity> yData = DataUtil.getFileData("Y.txt");
		for (int i = 0; i < xData.size(); i++) {
			RecoredIdentity xDat = xData.get(i);
			RecoredIdentity yDat = yData.get(i);

			if (xDat.equals(yDat)) {
				exact += xDat.getTransactionID() + "" + yDat.getTransactionID() + " ";
				map.put("exact", exact);
			} else if (xDat.getAccountID().equals(yDat.getAccountID())
					&& (xDat.getAmount().equals(yDat.getAmount()) || xDat.getAmount().equals(yDat.getAmount() - 0.01))
					&& (xDat.getPostingDate().equals(yDat.getPostingDate())
							|| DataUtil.dateCompByWeak(xDat.getPostingDate(), yDat.getPostingDate()))) {

				week += xDat.getTransactionID() + "" + yDat.getTransactionID() + " ";
				map.put("weak", week);
			} else {
				breakX += xDat.getTransactionID() + " ";
				breakY += yDat.getTransactionID() + " ";
				map.put("breakX", breakX);
				map.put("breakY", breakY);
			}
		}
		System.out.println("#XY exact matches \n" + map.get("exact"));
		System.out.println("#XY weak matches \n" + map.get("weak"));
		System.out.println("#X breaks \n" + map.get("breakX"));
		System.out.println("#Y breaks \n" + map.get("breakY"));
   	}
}
