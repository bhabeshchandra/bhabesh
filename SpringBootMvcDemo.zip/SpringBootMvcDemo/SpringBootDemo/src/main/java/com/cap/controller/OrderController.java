package com.cap.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController

@RequestMapping("/order/v1")
public class OrderController {
	@GetMapping("/orders")
   public String  getAllOrder() {
		
        return "Successfully Ordered";
    }
}
