package com.cap.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cap.model.Login;
import com.cap.model.User;

//@RequestMapping("/order/v1")
@Controller
public class MvcController {
	
	@RequestMapping(value="/login", method=RequestMethod.POST)
	   public String getAllOrder(@ModelAttribute("login")  Login login,
			   ModelMap model) {
		
			System.out.println("UserName: "+login.getUsername());
			System.out.println("UserName: "+login.getPassword());
			
			model.addAttribute("name",login.getUsername());
			
	        return "response";
	    }
	
	@RequestMapping(value="/profile", method=RequestMethod.GET)
	   public String editProfile() {
		  return "userprofile";
	    }
	
	@RequestMapping(value="/editregister", method=RequestMethod.GET)
	   public String editRegister() {
		System.out.println("editregister ********** ");
			
	        return "registerform";
	    }
	
	@RequestMapping(value="/register", method=RequestMethod.POST)
	   public String register(@ModelAttribute("user") User user,
			   ModelMap model) {
		System.out.println("editregister ********** ");
		model.addAttribute("user",user);
	        return "registersuccess";
	    }

}
