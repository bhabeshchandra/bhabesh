alert("WelCome to JS file");

function myFunction() {
    document.getElementById("demo").innerHTML = "This content has been changed by javascript";
};
myFunction();