package com.cap.controller;

@RestController
@RequestMapping("/order/v1")
public class MvcController {
	@GetMapping("/orders")
	   public String  getAllOrder() {
			
	        return "Successfully Ordered CLI**";
	    }
}
