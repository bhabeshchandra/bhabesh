package com.cap;

public class CarMainFactory {

	public static Car getMileage(int mileage, int kmpl) {
        Car car = null;
        switch (mileage) {
        case 0:
            car = new WagonR(mileage, kmpl);
            break;
 
        case 1:
            car = new HondaCity(mileage,kmpl);
            break;
 
        case 2:
            car = new InnovaCrysta(mileage,kmpl);
            break;
 
        default:
            break;
        }
        return car;
    }
	public static void main(String[] args) {
    // Test.getMileage(0,20);
    // Test.getMileage(1,30);
     CarMainFactory.getMileage(0,40);
     
	}

}
