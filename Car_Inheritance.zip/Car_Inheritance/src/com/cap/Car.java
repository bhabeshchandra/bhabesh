package com.cap;

abstract class Car {
	private int mileage;
	private int kmpl;
	Car(int mileage,int kmpl){
	this.mileage=mileage;
	this.kmpl=kmpl;
		getMileage(kmpl);
	}
	abstract String getIsSedan();
	abstract void getSeats();
	abstract void getMileage(int kmpl);
}
