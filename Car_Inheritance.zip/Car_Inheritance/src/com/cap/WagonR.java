package com.cap;

public class WagonR extends Car {
	
	private int mileage;
	WagonR(int mileage, int kmpl){
		super(mileage,kmpl);
		
	}
	
	public String getIsSedan() {
        System.out.println("WagonR IsSedan");
        return "WagonR IsSedan";
    }
	
	public void getSeats() {
        System.out.println("WagonR Seats");
    }
	
	public void getMileage(int kmpl) {
        System.out.println("WagonR is not a sedan and 4 seater and has a mileage of around "+ kmpl+ " kmpl");
    }

}
