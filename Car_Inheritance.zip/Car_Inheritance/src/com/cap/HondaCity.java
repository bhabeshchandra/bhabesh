package com.cap;

public class HondaCity extends Car {
	
	private int mileage;
	//private int kmpl;
	HondaCity(int mileage,int kmpl){
		super(mileage,kmpl);
		//this.kmpl=kmpl;
	}
	
	public String getIsSedan() {
        System.out.println("HondaCity IsSedan");
        return "HondaCity IsSedan";
    }
	
	public void getSeats() {
        System.out.println("HondaCity Seats");
        //return "HondaCity Seats";
    }
	
	public void getMileage(int kmpl) {
        System.out.println("HondaCity is a sedan and has 4 seater and has a mileage of around "+ kmpl+ " kmpl");
       // return "HondaCity Mileage";
    }

}
