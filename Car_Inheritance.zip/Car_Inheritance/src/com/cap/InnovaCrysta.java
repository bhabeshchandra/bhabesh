package com.cap;

public class InnovaCrysta extends Car {
	
	private int mileage;
	InnovaCrysta(int mileage, int kmpl){
		super(mileage, kmpl);
	}
	
	public String getIsSedan() {
        System.out.println("InnovaCrysta IsSedan");
        return "InnovaCrysta IsSedan";
    }
	
	public void getSeats() {
        System.out.println("InnovaCrysta Seats");
       // return "InnovaCrysta Seats";
    }
	
	public void getMileage(int kmpl) {
        System.out.println("InnovaCrysta is not a sedan and has 6 seater and has a mileage of around "+ kmpl+ " kmpl");
       // return "InnovaCrysta Mileage";
    }

}
