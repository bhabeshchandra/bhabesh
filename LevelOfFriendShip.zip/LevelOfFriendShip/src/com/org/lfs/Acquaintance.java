package com.org.lfs;

public class Acquaintance {
	private String name;
	Acquaintance() {
	}
	
	Acquaintance(String name) {
		this.name = name;
		getStatus(name);
	}
public void getStatus(String name) {
	System.out.println(name+" is just an Acquaintance."+"\n");
}
}

