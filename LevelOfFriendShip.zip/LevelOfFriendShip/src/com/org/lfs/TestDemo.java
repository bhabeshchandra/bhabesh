package com.org.lfs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TestDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		 * Scanner in = new Scanner(System.in); int n = in.nextInt(); String[] strings =
		 * new String[n]; for(int strings_i = 0; strings_i < n; strings_i++){
		 * strings[strings_i] = in.next(); // System.out.println("ccc"); }
		 */
		
		ArrayList<String> act = new ArrayList<>(Arrays.asList("Acquaintance", "Jaden"));
		ArrayList<String> frind = new ArrayList<>(Arrays.asList("Friend", "Jake", "Florida"));
		ArrayList<String> bestfrind = new ArrayList<>(Arrays.asList("BestFriend", "Ryan", "Utah", "Dangerous"));
		ArrayList<String> frind2 = new ArrayList<>(Arrays.asList("Friend", "David", "Texas"));
		List<ArrayList<String>> lst = new ArrayList<ArrayList<String>>();
		lst.add(act);
		lst.add(frind);
		lst.add(bestfrind);
		lst.add(frind2);

		TestFriend(lst);
	}

	public static void TestFriend(List<ArrayList<String>> lst) {
		for (ArrayList<String> strings : lst) {
			if (strings.size() == 2 && "Acquaintance".equals(strings.get(0))) {
				Acquaintance acqua = new Acquaintance(strings.get(1));
			} else if (strings.size() == 3 && "Friend".equals(strings.get(0))) {
				Friend frnd = new Friend(strings.get(1), strings.get(2));
			} else if (strings.size() == 4 && "BestFriend".equals(strings.get(0))) {
				BestFriend frnd = new BestFriend(strings.get(1), strings.get(2), strings.get(3));
			}

		}
	}
}
