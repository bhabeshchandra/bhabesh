package com.org.lfs;

import javax.net.ssl.HostnameVerifier;

public class BestFriend extends Friend{
	private String favoriteSong;
	BestFriend(String name, String homeTown, String favoriteSong){
		super();
		this.homeTown=homeTown;
		this.favoriteSong=favoriteSong;
		getStatus(name,homeTown,favoriteSong);
	}
	public void getStatus(String name, String homeTown, String favoriteSong) {
		System.out.println(name+" is my best friend. He is from "+homeTown+ "and his favorite song is "+favoriteSong+"\n");
	}
}
