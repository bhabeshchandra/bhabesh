package com.org.lfs;

public class Friend extends Acquaintance{
	protected String homeTown;
	Friend(){
	}
	Friend(String name, String homeTown){
		super();
		this.homeTown=homeTown;
		getStatus(name,homeTown);
	}
	public void getStatus(String name,String homeTown) {
		System.out.println(name+" is a friend and he is from "+homeTown+"\n");
	}
}
