package org.cap.dao;

import java.util.List;

import org.cap.model.Customer;

public interface ICustomerDao {
	
	public List<Customer> getAllCustomers();

	public List<Customer> createCustomer(Customer customer);
	public List<Customer> updateCustomer(Customer customer);
	public List<Customer> deleteCustomer(int customerId);
	public Customer findCustomer(int customerId);
}
