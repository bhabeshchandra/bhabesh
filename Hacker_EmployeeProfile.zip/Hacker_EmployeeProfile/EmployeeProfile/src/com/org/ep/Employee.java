package com.org.ep;

abstract class Employee {

	public abstract int getSalary();
	
	public abstract void setSalary(int salary);
	
	public abstract String getGrade();
	
	public abstract void setGrade(String grade);
	
	
	public void lable() {
		
		System.out.println("Employee's data:\n"+"GRADE : "+getGrade()+"\nSALARY : "+getSalary());
	}
	
}
