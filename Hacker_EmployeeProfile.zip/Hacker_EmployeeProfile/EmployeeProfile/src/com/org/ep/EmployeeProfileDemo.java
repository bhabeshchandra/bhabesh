package com.org.ep;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class EmployeeProfileDemo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String[] mngStr = { "MANAGER", "A", "70000" };
		String[] engStr = { "ENGINEER", "B", "50000" };
		List<String> arrMng = new ArrayList(Arrays.asList(mngStr));
		List<String> arrEng = new ArrayList(Arrays.asList(engStr));

		List<List<String>> lst = new ArrayList<List<String>>();
		lst.add(arrMng);
		lst.add(arrEng);

		Manager mng = new Manager();
		Engineer eng = new Engineer();

		for (List<String> arrStr : lst) {
			if (arrStr.contains("MANAGER")) {
				mng.setGrade(arrStr.get(1));
				mng.setSalary(Integer.parseInt(arrStr.get(2)));
				mng.lable();
			} else if (arrStr.contains("ENGINEER")) {
				eng.setGrade(arrStr.get(1));
				eng.setSalary(Integer.parseInt(arrStr.get(2)));
				eng.lable();
			}

		}

	}

}
