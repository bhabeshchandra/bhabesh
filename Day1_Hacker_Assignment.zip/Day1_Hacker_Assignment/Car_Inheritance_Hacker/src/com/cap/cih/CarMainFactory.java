package com.cap.cih;

import java.util.Scanner;

public class CarMainFactory {

	public static void main(String args[]) {
		Car car;
		Scanner scan = new Scanner(System.in);

		System.out.println("Please enter two numbers between 0-2 inclusive and between 5-30 inclusive ");
		int carType = scan.nextInt();
		if (carType >= 0 && carType <= 2) {
			int kmpl = scan.nextInt();
			if (kmpl >= 5 && kmpl <= 30) {
				if (carType == 0) {
					car = new WagonR(kmpl);
					System.out.println("A WagonR is not Sedan, is " + car.getSeats() + " Seater, and has a millage of arround " + car.getMileage() + " kmpl.");
				} else if (carType == 1) {
					car = new HondaCity(kmpl);
					System.out.println("A HondaCity is Sedan, is " + car.getSeats() + " Seater, and has a millage of arround " + car.getMileage() + " kmpl.");
				} else if (carType == 2) {
					car = new InnovaCar(kmpl);
					System.out.println("A Innova is not Sedan, is " + car.getSeats() + " Seater, and has a millage of arround " + car.getMileage() + " kmpl.");
				}
			}
			else {
				System.out.println(" Please enter valid mileage");
			}
		 }
		else {
			System.out.println(" Please enter valid Car Type");
		}

	}

}
