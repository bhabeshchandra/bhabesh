package com.cap.cih;

public abstract class Car {
	
	String seats;
	boolean isSedan;
	
	public Car(boolean isSedan, String seats) {
		this.isSedan= isSedan;
		this.seats = seats;
	}
	
	public boolean getIsSedan() {
		return isSedan;
		}

	public String getSeats() {
		return seats;
	}
	public abstract String getMileage();
}
