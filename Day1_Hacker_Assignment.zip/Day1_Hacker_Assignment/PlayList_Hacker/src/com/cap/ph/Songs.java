package com.cap.ph;

public class Songs {

    private	String songName;

	public Songs(String songName) {

		this.songName = songName;
	}

	public String getName() {
		return songName;
	}

	public void setName(String name) {
		this.songName = name;
	}

	public String toString() {
		return "Songs [songName=" + songName + "]";
	}
}
