package com.cap.ph;

import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

public class PlayList {
	/**
	 * @param args
	 */	
	public static void playLists(List<Songs> songList) {
	      System.out.println("Please Enter 0 for Quit from playlist\n" +
	    		  "Please Enter 1 for Play Next Song\n" +
	    		  "Please Enter 2 for Play Previous Song\n");
	      
	      Scanner scanner = new Scanner(System.in);
	        boolean forward = true;
	        boolean isQuit = false;
	        ListIterator<Songs> lstItr = songList.listIterator();

	          if (songList.size() == 0) {
	              System.out.println("Please add some song in playlist");
	              return;
	          } else {
	              System.out.println("Now playing " + lstItr.next().toString());
	             	          }
	          while (!isQuit) {
	              int choose = scanner.nextInt();
	              scanner.nextLine();

	              switch (choose) {
	                  case 0:
	                      System.out.println("End of the Playlist");
	                      isQuit = true;
	                      break;

	                  case 1: 
	                      if (!forward) {
	                          if (lstItr.hasNext()) {
	                        	  lstItr.next(); 
	                          }
	                          forward = true; 
	                      }
	                      if (lstItr.hasNext()) {  
	                          System.out.println("Now playing " + lstItr.next().toString()); 
	                      } else {
	                          System.out.println("We have reached the end of the playlist");
	                          forward = false;
	                      }
	                      break;

	                  case 2:  
	                      if (forward) {
	                          if (lstItr.hasPrevious()) {  
	                        	  lstItr.previous();
	                          }
	                          forward = false;
	                      }
	                      if (lstItr.hasPrevious()) { 
	                          System.out.println("Now playing " + lstItr.previous().toString());
	                      } else {  
	                          System.out.println("We are at the start of the playlist");
	                          forward = true;
	                      }
	                      break;
	              }
		
	}

	
}

	
}
