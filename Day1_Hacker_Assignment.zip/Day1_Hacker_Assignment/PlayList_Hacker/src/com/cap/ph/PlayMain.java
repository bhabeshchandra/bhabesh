package com.cap.ph;

import java.util.ArrayList;
import java.util.List;

public class PlayMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Songs> library = new ArrayList<Songs>(); 
		library.add(new Songs("money"));
		library.add(new Songs("wishyouwherehere"));
		library.add(new Songs("welcometothemachine"));
		library.add(new Songs("time"));
		library.add(new Songs("Dhemmi"));
		
		  PlayList.playLists(library);
	}

}
