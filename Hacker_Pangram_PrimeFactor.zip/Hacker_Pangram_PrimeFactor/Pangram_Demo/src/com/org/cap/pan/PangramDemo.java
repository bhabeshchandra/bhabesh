package com.org.cap.pan;

import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class PangramDemo {
	/*
	 * 1. How to find pangram- they will giving you a string.. logic is to find all
	 * the alphabets should be there in that string, irrespective of lowercase or
	 * upper case If all are present then it is pangram.
	 */

	private static final int ALPHABET = 26;

	public static void main(String[] args) {
		PangramDemo pd = new PangramDemo();
		String str = "The Quick Brown Fox Jumps Over The Lazy Dog";
		boolean result = pd.isPangram(str);
		if (result)
			System.out.print("\nThe given string is a pangram.");
		else
			System.out.print("\nThe given string is not a pangram.");

	}

	public static boolean isPangram(String str) {
		if (str == null) {
			return false;
		}
		String strUpper = str.toUpperCase();

		Stream<Character> filterData = strUpper.chars().filter(item -> ((item >= 'A' && item <= 'Z')))
				.mapToObj(c -> (char) c);

		Map<Character, Boolean> alphabetMap = filterData
				.collect(Collectors.toMap(item -> item, k -> Boolean.TRUE, (p1, p2) -> p1));

		return alphabetMap.size() == ALPHABET;
	}
}
