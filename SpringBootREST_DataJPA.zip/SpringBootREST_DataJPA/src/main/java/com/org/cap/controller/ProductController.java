package com.org.cap.controller;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.org.cap.model.Product;
import com.org.cap.service.IProductService;

	@RestController
	@RequestMapping("/product")
	public class ProductController {
		
		@Autowired
		private IProductService productService;

		@GetMapping("/products")
		public ResponseEntity<List<Product>> getAllProducts(){
			 List<Product> products =productService.getAllProducts();
			if(products==null || products.isEmpty())
				return new ResponseEntity("Sorry! No Product Available!", 
						HttpStatus.NOT_FOUND);
			return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
		}
		
		//produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
		// consumes = MediaType.APPLICATION_XML_VALUE 
		@GetMapping(value ="/productsxml", produces= MediaType.APPLICATION_XML_VALUE)
		public ResponseEntity<List<Product>> getAllProductsXml() {
			List<Product> products = productService.getAllProducts();
			if (products == null || products.isEmpty()) {
				return new ResponseEntity("Product are Not Avilable ", HttpStatus.NOT_FOUND);
			 }
			return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
		}
		
		@PostMapping("/product")
		public ResponseEntity<List<Product>> createProduct(
				@RequestBody Product product){
			List<Product> products=productService.createProduct(product);
			if(products==null || products.isEmpty())
				return new ResponseEntity("Insertion Failed!!", 
						HttpStatus.BAD_REQUEST);
			return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
		}
		

		@DeleteMapping("/product/{productId}")
		public ResponseEntity<List<Product>> deleteProduct(@PathVariable("productId") int productId) {
			List<Product> products = productService.deleteProduct(productId);
			if (products == null || products.isEmpty()) {
				return new ResponseEntity("Product is not deleted!", HttpStatus.NOT_FOUND);
			}
			return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
		}
		
		@PutMapping("/product")
		public ResponseEntity<List<Product>> updateProduct(
				@RequestBody Product product) {
			List<Product> products = productService.updateProduct(product);

			if (products == null || products.isEmpty()) {
				return new ResponseEntity("Product updated Successfully", HttpStatus.NOT_FOUND);
			}
			return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
		}


		@PatchMapping("/product")
		public ResponseEntity<List<Product>> updateProd(@RequestBody Product product) {
			List<Product> customers = productService.updateProduct(product);

			if (customers == null || customers.isEmpty()) {
				return new ResponseEntity("Product updated Successfully", HttpStatus.NOT_FOUND);
			}
			return new ResponseEntity<List<Product>>(customers, HttpStatus.OK);
		}

	}

