package com.org.cap.service;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.org.cap.model.Product;
import com.org.cap.reposotory.ProductRepository;

@Service
public class ProductServiceImpl implements IProductService{
	
	@Autowired
	private ProductRepository productRepo;

	@Override
	public List<Product> getAllProducts() {
		
		return productRepo.findAll();
	}

	@Override
	public List<Product> createProduct(Product product) {
		productRepo.save(product);
		return productRepo.findAll();
	}

	@Override
	public Product findProduct(Integer productId) {
		Product product= productRepo.getOne(productId);
		return product;
	}

	@Override
	public List<Product> deleteProduct(Integer productId) {
		productRepo.deleteById(productId);
		
		return productRepo.findAll();
	}
	
	@Override
	public List<Product> updateProduct(Product product) {
		productRepo.save(product);
		return productRepo.findAll();
	}
}
