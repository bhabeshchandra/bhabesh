package com.org.operator;

import java.util.Scanner;

public class OperatorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		double mealcost = sc.nextInt();
		int tipPercent = sc.nextInt();
		int taxPercent = sc.nextInt();
		sc.close();
		
		System.out.println("MealCost: "+mealCost(mealcost,tipPercent,taxPercent) );
	}
	static int mealCost(double mealcost,int tipPercent,int taxPercent) {
		double tip=(mealcost*tipPercent)/100;
		double tax=(mealcost*taxPercent)/100;
		double totalCost=tip+tax+mealcost;
		
		return (int) Math.round(totalCost);
	}
}
