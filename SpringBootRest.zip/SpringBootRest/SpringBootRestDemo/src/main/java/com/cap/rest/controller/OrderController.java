package com.cap.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cap.rest.dao.ICustomerDao;
import com.cap.rest.model.Customer;

@RestController
@RequestMapping("/order/v1")
public class OrderController {

	@Autowired
	private ICustomerDao customerDao;

	@GetMapping("/orders")
	   public String  getAllOrder() {
			
	        return "Successfully Ordered";
	    }
	
	@GetMapping("/customers")
	public ResponseEntity<List<Customer>> getAllCustomerOrder() {
		List<Customer> customer = customerDao.getAllCustomers();
		if (customer == null || customer.isEmpty()) {
			return new ResponseEntity("Customer are Not Avilable ", HttpStatus.NOT_FOUND);
		 }
		return new ResponseEntity<List<Customer>>(customer, HttpStatus.OK);
	}

	
	@PostMapping("/addcustomer")
	public ResponseEntity<List<Customer>> addCustomer(
			@RequestBody Customer customer){
		List<Customer> customerLst= customerDao.addCustomer(customer);
		if(customerLst==null || customerLst.isEmpty()) {
			return new ResponseEntity("Customer is not Added", 
					HttpStatus.NOT_FOUND);
		 }
		return new ResponseEntity<List<Customer>>(customerLst, 
				HttpStatus.OK);
	}
	
	@DeleteMapping("/deletecustomer/{customerId}")
	public ResponseEntity<List<Customer>> deleteCustomer(@PathVariable("customerId") int customerId) {
		List<Customer> customers = customerDao.deleteCustomer(customerId);
		if (customers == null || customers.isEmpty()) {
			return new ResponseEntity("Customer is not deleted!", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Customer>>(customers, HttpStatus.OK);
	}
	
	@PutMapping("/updatecustomer")
	public ResponseEntity<List<Customer>> updateCustomer(@RequestBody Customer customer) {
		List<Customer> customers = customerDao.updateCustomer(customer);

		if (customers == null || customers.isEmpty()) {
			return new ResponseEntity("Customer updated Successfully", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Customer>>(customers, HttpStatus.OK);
	}


	@PatchMapping("/customer")
	public ResponseEntity<List<Customer>> update(@RequestBody Customer customer) {
		List<Customer> customers = customerDao.updateCustomer(customer);

		if (customers == null || customers.isEmpty()) {
			return new ResponseEntity("Customer updated Successfully", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Customer>>(customers, HttpStatus.OK);
	}
	
}
