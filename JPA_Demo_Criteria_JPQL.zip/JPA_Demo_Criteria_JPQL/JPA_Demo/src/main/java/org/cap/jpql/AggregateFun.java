package org.cap.jpql;

import javax.persistence.EntityManager;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import org.cap.criteria.Department;

public class AggregateFun {

	public static void main(String args[]) {

		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("capg");
		EntityManager entityManager = entityManagerFactory.createEntityManager();

		Department dept1 = new Department(101, "Accounting", 1001);
		Department dept2 = new Department(102, "Sales", 1002);
		Department dept3 = new Department(103, "Operation", 1003);
		Department dept4 = new Department(104, "Research", 1004);

		entityManager.getTransaction().begin();
		entityManager.persist(dept1);
		entityManager.persist(dept2);
		entityManager.persist(dept3);
		entityManager.persist(dept4);


		Query maxQuery = entityManager.createQuery("Select MAX(d.deptid) from Department d");
		System.out.println("Maximum Deptid : " + maxQuery.getSingleResult());

		Query minQuery = entityManager.createQuery("Select MIN(d.deptid) from Department d");
		System.out.println("Minimum Deptid : " + minQuery.getSingleResult());
		entityManager.getTransaction().commit();
		entityManager.close();
		entityManager.close();
	}
}
