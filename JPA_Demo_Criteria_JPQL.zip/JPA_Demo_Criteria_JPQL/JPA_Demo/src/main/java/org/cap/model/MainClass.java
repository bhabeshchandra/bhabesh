package org.cap.model;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class MainClass {

	public static void main(String[] args) {
		
		EntityManagerFactory entityManagerFactory=
				Persistence.createEntityManagerFactory("capg");
		
		EntityManager entityManager=
				entityManagerFactory.createEntityManager();
		
		EntityTransaction transaction= entityManager.getTransaction();
		
		transaction.begin();
		
		/*
		 * Customer customer=new Customer(1234,"Jack",LocalDate.now(),34000);
		 * 
		 * Customer tom=new Customer(45435,"TOM",LocalDate.now(),1200,"tom@gmail.com");
		 * Customer annie=new
		 * Customer(789879,"Annie",LocalDate.now(),1200,"annie@gmail.com");
		 * 
		 * Customer customer1=new Customer(); customer1.setCutomerId(1111);
		 * customer1.setCustomerName("Kamal"); customer1.setRegAmount(1200);
		 * customer1.setCustPassword("kamal123");
		 * 
		 * entityManager.persist(customer); entityManager.persist(tom);
		 * entityManager.persist(annie); entityManager.persist(customer1);
		 */
			
			//trigger insert query
		
		
		
		
		
		
		//Read the object from DB
		//Customer customer=entityManager.find(Customer.class, 45435);
		//System.out.println(customer);
		
		
		
		//customer.setRegAmount(5000.0);
		//entityManager.merge(customer);
		
		//delete Customer
		//entityManager.remove(customer);
		
		
		
		/*
		 * String sql="from Customer"; List<Customer> customers=
		 * entityManager.createQuery(sql).getResultList();
		 * 
		 * for(Customer customer:customers) System.out.println(customer);
		 */
		
		//String sql="select new Customer(cust.cutomerId, cust.customerName) from Customer cust";
		String sql="from Customer cust "
				+ "where cust.regAmount=:regAmtParam";
		Query query= entityManager.createQuery(sql);
		query.setParameter("regAmtParam", 1200.0);
		List<Customer> customers= query.getResultList();
		
		for(Customer customer:customers)
			System.out.println(customer);
		
		
		String sql1="select customerName from Customer";
		List<String> names= entityManager.createQuery(sql1).getResultList();
		System.out.println(names);
		
		String sql2="select count(customerName) from Customer";
		List<Object> total=entityManager.createQuery(sql2).getResultList();
		System.out.println("Total no of Customers:" + total.get(0));
		
		transaction.commit(); //All changes stored permenatly into DB
		entityManager.close();
		entityManagerFactory.close();
		
	}

}
