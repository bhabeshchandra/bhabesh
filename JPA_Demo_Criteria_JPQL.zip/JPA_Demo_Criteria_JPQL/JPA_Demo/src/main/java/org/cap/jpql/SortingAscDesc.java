package org.cap.jpql;

import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.cap.criteria.Department;

public class SortingAscDesc {

	public static void main(String args[]) {

		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("capg");
		EntityManager entityManager = entityManagerFactory.createEntityManager();

		Department dept1 = new Department(101, "Accounting", 1001);
		Department dept2 = new Department(102, "Sales", 1002);
		Department dept3 = new Department(103, "Operation", 1003);
		Department dept4 = new Department(104, "Research", 1004);

		entityManager.getTransaction().begin();
		entityManager.persist(dept1);
		entityManager.persist(dept2);
		entityManager.persist(dept3);
		entityManager.persist(dept4);

		Query queryAsc = entityManager.createQuery("Select d from Department d order by d.deptid asc");

		@SuppressWarnings("unchecked")
		List<Department> lstAsc = (List<Department>) queryAsc.getResultList();
		System.out.println("Asscending Order");
		for (Department dept : lstAsc) {
			System.out.print(dept.getDeptid());
			System.out.print("\t" + dept.getDeptname());
			System.out.println("\t" + dept.getDeptloc());
		}


		Query queryDesc = entityManager.createQuery("Select d from Department d order by d.deptid desc");

		@SuppressWarnings("unchecked")
		List<Department> lstDesc = (List<Department>) queryDesc.getResultList();
		System.out.println("Descending Order");
		for (Department dept : lstDesc) {
			System.out.print(dept.getDeptid());
			System.out.print("\t" + dept.getDeptname());
			System.out.println("\t" + dept.getDeptloc());
		}
		entityManager.getTransaction().commit();
		entityManager.close();
		entityManager.close();
	}

}
