package com.cap.anagram;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Anagrams {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str[] = new String[4];
		Scanner scan = new Scanner(System.in);
		System.out.println("Please Enter at least four words! ");
		for (int i = 0; i < str.length; i++)
			str[i] = scan.nextLine();
		int enterStr = str.length;
		funWithAnagrams(str, enterStr);
	}
	private static void funWithAnagrams(String[] str, int lenthString){
		List<String> asList = new ArrayList<String>(Arrays.asList(str));
		boolean status = true;  
		for (int i = 0; i < lenthString; i++)
			for (int j = i + 1; j < lenthString; j++) {
				if (str[i].length() != str[j].length())
					status =false;
				else {
					char[] ArrayS1 = str[i].toLowerCase().toCharArray();
					char[] ArrayS2 = str[j].toLowerCase().toCharArray();
					Arrays.sort(ArrayS1);
					Arrays.sort(ArrayS2);
					if (Arrays.equals(ArrayS1, ArrayS2)) {
						if (asList.contains(str[j])) {
							asList.remove(str[j]);
						}
					} 
				  }
				}
		System.out.println("Anagrams Results are: \n");
		for (String print : asList)
			System.out.println(print);
	}
	
	}

