package com.cap.rest.dao;

import java.util.List;

import com.cap.rest.model.Customer;

public interface ICustomerDao {
	public List<Customer> getAllCustomers();
	public List<Customer> addCustomer(Customer customer);
	public List<Customer> deleteCustomer(int customerId);
	public List<Customer> updateCustomer(Customer customer);
	public List<Customer> putUpdateCustomer(Customer customer);
}
